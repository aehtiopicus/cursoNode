#!/bin/bash

# Tests
grunt test
