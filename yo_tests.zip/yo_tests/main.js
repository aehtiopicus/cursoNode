'use strict';

var helloWorld = require('./lib/hello-world');
var logger = require('./lib/logger');

logger.info(helloWorld());