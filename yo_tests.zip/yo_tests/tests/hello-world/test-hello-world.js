'use strict';

const should = require('should');
const HelloWorld = require('../../lib/hello-world');

describe('Hello World', () => {

  describe('Hello World return', () => {

    it('should return Hello World when execute HelloWorld function', function () {
      HelloWorld().should.equal('Hello World');
    });

  });

});
